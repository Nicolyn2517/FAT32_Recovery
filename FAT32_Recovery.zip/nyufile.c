#include <ctype.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h> 
#include <sys/mman.h>
#include <fcntl.h>
#include <openssl/sha.h>
#include <math.h>

#define SHA_DIGEST_LENGTH 20

// unsigned char *SHA1(const unsigned char *d, size_t n, unsigned char *md);

//references:
// https://blog.csdn.net/21aspnet/article/details/6730124
// https://blog.csdn.net/qq_45490227/article/details/124004784

#define handle_error(msg) \
           do { perror(msg); exit(EXIT_FAILURE); } while (0)

#pragma pack(push,1)
typedef struct BootEntry {
unsigned char BS_jmpBoot[3]; /* Assembly instruction to jump to boot code */
unsigned char BS_OEMName[8]; /* OEM Name in ASCII */
unsigned short BPB_BytsPerSec; /* Bytes per sector. Allowed values include 512,
 1024, 2048, and 4096 */	 //512
unsigned char BPB_SecPerClus; /* Sectors per cluster (data unit). Allowed values
 are powers of 2, but the cluster size must be 32KB //1
 or smaller */
unsigned short BPB_RsvdSecCnt; /* Size in sectors of the reserved area */ //32
unsigned char BPB_NumFATs; /* Number of FATs */ //2
unsigned short BPB_RootEntCnt; /* Maximum number of files in the root directory for
 FAT12 and FAT16. This is 0 for FAT32 */
unsigned short BPB_TotSec16; /* 16-bit value of number of sectors in file system */ //512
unsigned char BPB_Media; /* Media type */
unsigned short BPB_FATSz16; /* 16-bit size in sectors of each FAT for FAT12 and
 FAT16. For FAT32, this field is 0 */
unsigned short BPB_SecPerTrk; /* Sectors per track of storage device */
unsigned short BPB_NumHeads; /* Number of heads in storage device */
unsigned int BPB_HiddSec; /* Number of sectors before the start of partition */
unsigned int BPB_TotSec32; /* 32-bit value of number of sectors in file system. //0
 Either this value or the 16-bit value above must be
 0 */
unsigned int BPB_FATSz32; /* 32-bit size in sectors of one FAT */ //4
unsigned short BPB_ExtFlags; /* A flag for FAT */
unsigned short BPB_FSVer; /* The major and minor version number */
unsigned int BPB_RootClus; /* Cluster where the root directory can be found */ //2
unsigned short BPB_FSInfo; /* Sector where FSINFO structure can be found */
unsigned short BPB_BkBootSec; /* Sector where backup copy of boot sector is located */
unsigned char BPB_Reserved[12]; /* Reserved */
unsigned char BS_DrvNum; /* BIOS INT13h drive number */
unsigned char BS_Reserved1; /* Not used */
unsigned char BS_BootSig; /* Extended boot signature to identify if the next three values are valid */
unsigned int BS_VolID; /* Volume serial number */
unsigned char BS_VolLab[11]; /* Volume label in ASCII. User defines when creating the file system */
unsigned char BS_FilSysType[8]; /* File system type label in ASCII */
} BootEntry;
#pragma pack(pop)

#pragma pack(push,1)
 typedef struct DirEntry {
     unsigned char DIR_Name[11];
     unsigned char DIR_Attr;
     unsigned char DIR_NTRes;
     unsigned char DIR_CrtTimeTenth; /* Created time (tenths of second) */
     unsigned short DIR_CrtTime;     /* Created time (hours, minutes, seconds) */
     unsigned short DIR_CrtDate;     /* Created day */
     unsigned short DIR_LstAccDate;  /* Accessed day */
     unsigned short DIR_FstClusHI;
     unsigned short DIR_WrtTime;
     unsigned short DIR_WrtDate;
     unsigned short DIR_FstClusLO;
     unsigned int DIR_FileSize;
} DirEntry;
#pragma pack(pop)

int main(int argc, char *argv[])
{
	int iflag = 0;
	int lflag = 0;
	char *rvalue = NULL;  
	char *Rvalue = NULL;  
	char *svalue = NULL;
	int ar_flag = 0;
	char disk_name[100];
	int c;
// -i
// -l
// -r filename
// -r filename -s sha1
// -R filename -s sha1
	while((c = getopt(argc, argv, "ilr:R:s:")) != -1)
	{
		if(optind == 2)//没有disk
		{
			ar_flag = 0;
			break;
		}
		ar_flag = 1; //there's more command line arguments
		switch(c)
		{
		case 'i':
			if(lflag || iflag || rvalue != NULL || Rvalue != NULL || svalue != NULL)
			{
				ar_flag = 0; 
				break;
			}
			else
				iflag = 1;
			break;
		case 'l':
			if(lflag || iflag || rvalue != NULL || Rvalue != NULL || svalue != NULL)
			{
				ar_flag = 0; 
				break;
			}
			else
				lflag = 1;
			break;
		case 'r':
			if(lflag || iflag || rvalue != NULL || Rvalue != NULL || svalue != NULL)
			{
				ar_flag = 0; 
				break;
			}
			else
			{
				rvalue = optarg; //argument of option r
				if(!strcmp(rvalue,"-s")) // == -s
				{
					ar_flag = 0;
					break;
				}
			}
			break;
		case 'R':
			if(lflag || iflag || rvalue != NULL || Rvalue != NULL || svalue != NULL)
			{
				ar_flag = 0; 
				break;
			}
			else
			{
				Rvalue = optarg; //argument of option R
				if(!strcmp(Rvalue,"-s") || (optind == argc)) // == -s
				{
					ar_flag = 0;
					break;
				}
			}			
			break;
		case 's':
			if(lflag || iflag || (rvalue == NULL && Rvalue == NULL) || svalue != NULL ) //只有s没有r或者R
			{
				ar_flag = 0;
				break;
			}
			else //s+r / s+R
			{
				svalue = optarg; //argument of option s
			}
			break;
		case '?': // not including in options
			ar_flag = 0;
			break;
		default:
			abort();
		}
		if(!ar_flag)
			break;
	}
	if(!ar_flag)
	{
		printf("Usage: ./nyufile disk <options>\n");
		printf("  -i                     Print the file system information.\n");
		printf("  -l                     List the root directory.\n");
		printf("  -r filename [-s sha1]  Recover a contiguous file.\n");
		printf("  -R filename -s sha1    Recover a possibly non-contiguous file.\n");
		return 1;
	}
	strcpy(disk_name,argv[optind]);
	
	struct stat sb;
	int fd = open(disk_name, O_RDWR);
	if (fd == -1)
		handle_error("open");

	// Get file size
	if (fstat(fd, &sb) == -1)
		handle_error("fstat");
	
	// Map file into memory
	char *addr = mmap(NULL, sb.st_size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
	if (addr == MAP_FAILED)
		handle_error("mmap");
	close(fd);

	BootEntry *bp = (BootEntry*)addr;
	int reser_bytes = bp->BPB_RsvdSecCnt * bp->BPB_BytsPerSec;
	// int fat_bytes = bp->BPB_NumFATs * bp->BPB_FATSz32 * bp->BPB_BytsPerSec;

	//milestone 2 -i
	if(iflag)
	{
		printf("Number of FATs = %d\n",bp->BPB_NumFATs);
		printf("Number of bytes per sector = %d\n",bp->BPB_BytsPerSec);
		printf("Number of sectors per cluster = %d\n",bp->BPB_SecPerClus);
		printf("Number of reserved sectors = %d\n",bp->BPB_RsvdSecCnt);
	}

	//milestone 3 -l
	
	if(lflag)
	{
		//root directory 位置
		int num_entries = 0;
		int next_cluster = bp->BPB_RootClus; //第一个cluster的初始位置
		int	first_offset = bp->BPB_RsvdSecCnt * bp->BPB_BytsPerSec + bp->BPB_NumFATs * bp->BPB_FATSz32 * bp->BPB_BytsPerSec ;
		int max_entries = bp->BPB_SecPerClus * bp->BPB_BytsPerSec / 32;

		while (next_cluster < 0x0ffffff8)
		{
			int offset = first_offset + (next_cluster -2) *bp->BPB_BytsPerSec*bp->BPB_SecPerClus;
			unsigned int * pp = (unsigned int *)(addr + reser_bytes + 4 * next_cluster);
			next_cluster = * pp;

			for (int i = 0; i < max_entries; i++)
				{
					DirEntry * dp = (DirEntry *)(addr + offset + i*32);
					if(dp->DIR_Name[0] == 0) //没有文件了
					{
						break;
					}
					// offset += sizeof(DirEntry);
					if(dp->DIR_Name[0] == 0xe5) //被删除的文件
						continue;
					else
					{
						char filename[20] = {0};
						int name_length = 0;
						//parse name
						strcpy(filename,(char *)dp->DIR_Name);
						for (int i = 0; i < 8; i++)
						{
							if(dp->DIR_Name[i] == ' ') //foo i=3
							{
								name_length = i; // name_length = 3
								break;
							}
						}
						if(name_length == 0)
						{
							name_length = 8;
						}

						//判断是否加.
						for (int i = 8; i < 11; i++)
						{
							if(dp->DIR_Name[i] != ' ')//扩展名不为空 -- 加.
							{
								filename[name_length] = '.';
								name_length++;
								i = 100;
							}
						}
						for (int i = 8; i < 11; i++)
						{
							if(dp->DIR_Name[i] != ' ')//扩展名不为空 -- 复制
							{
								filename[name_length] = dp->DIR_Name[i];
								name_length++;
							}
						}
						filename[name_length] = '\0';

						printf("%s",filename); //HELLO.TXT
						
						if(dp->DIR_Attr & 0x10) //是目录
						{
							printf("/ (starting cluster = %u)\n",(dp->DIR_FstClusHI << 16) + dp->DIR_FstClusLO);
						}
						else //是文件
						{
							if(dp->DIR_FileSize != 0)//不是空文件
								printf(" (size = %u, starting cluster = %u)\n",dp->DIR_FileSize,(dp->DIR_FstClusHI << 16) + dp->DIR_FstClusLO);
							else
								printf(" (size = 0)\n");
						}
						num_entries++;
				}
			}
				
		}
			printf("Total number of entries = %d\n",num_entries);
	}

	//milestone 4 -r filename small file
	//milestone 5  one continuous file
	//milestone 6 multiple same name files
	//milestion 7 use sha1 to recover same name target file  -r filename -s sha1
	if(rvalue != NULL && svalue == NULL)
	{
		char raw_file[500];
		strcpy(raw_file,rvalue);
		int recover_num = 0;
		//root directory 位置

		int next_cluster = bp->BPB_RootClus; //第一个cluster的初始位置
		int	first_offset = bp->BPB_RsvdSecCnt * bp->BPB_BytsPerSec + bp->BPB_NumFATs * bp->BPB_FATSz32 * bp->BPB_BytsPerSec ;
		int max_entries = bp->BPB_SecPerClus * bp->BPB_BytsPerSec / 32;

		DirEntry * recover_file = NULL;

		while (next_cluster < 0x0ffffff8)
		{
			int offset = first_offset + (next_cluster -2) *bp->BPB_BytsPerSec*bp->BPB_SecPerClus;
			unsigned int * pp = (unsigned int *)(addr + reser_bytes + 4 * next_cluster);
			next_cluster = * pp;

			for (int i = 0; i < max_entries; i++)
				{
					DirEntry * dp = (DirEntry *)(addr + offset + i*32);
					if(dp->DIR_Name[0] == 0) //没有文件了
						break;
					
					//get filename -- HELLO.TXT
					char filename[20] = {0};
					int name_length = 0;
					//parse name
					strcpy(filename,(char *)dp->DIR_Name);
					for (int i = 0; i < 8; i++)
					{
						if(dp->DIR_Name[i] == ' ') //foo i=3
						{
							name_length = i; // name_length = 3
							break;
						}
					}
					if(name_length == 0)
					{
						name_length = 8;
					}
					//判断是否加.
					for (int i = 8; i < 11; i++)
					{
						if(dp->DIR_Name[i] != ' ')//扩展名不为空 -- 加.
						{
							filename[name_length] = '.';
							name_length++;
							i = 100;
						}
					}
					for (int i = 8; i < 11; i++)
					{
						if(dp->DIR_Name[i] != ' ')//扩展名不为空 -- 复制
						{
							filename[name_length] = dp->DIR_Name[i];
							name_length++;
						}
					}
					filename[name_length] = '\0';	
				
					if(dp->DIR_Name[0] == 0xe5) //被删除的文件
					{
						if(!strcmp(&raw_file[1],&filename[1])) //名字相同
						{
							recover_num++;
							//如果num > 1退出
							if(recover_num > 1)
								break;
							//先存
							recover_file = (DirEntry *)(addr + offset + i*32);

						}
					}
			}
			if(recover_num > 1)
				break;
		}
		if(recover_num == 0) //没找到
		{
			printf("%s: file not found\n",raw_file);
		}
		if(recover_num == 1)//有一个符合的文件
		{
			//恢复文件
			recover_file->DIR_Name[0] = raw_file[0];
			//恢复fat
			for (int i = 0; i < bp->BPB_NumFATs; i++)
			{
				unsigned int starting_cluster = (recover_file->DIR_FstClusHI << 16) + recover_file->DIR_FstClusLO;
				unsigned int * pp = (unsigned int *)(addr + reser_bytes + 4 * starting_cluster + i * bp->BPB_FATSz32 * bp->BPB_BytsPerSec);
				unsigned int one_cluster = bp->BPB_BytsPerSec * bp->BPB_SecPerClus;
				if(recover_file->DIR_FileSize > one_cluster) //大于一个cluster
				{
					int num_clusters = 0;
					if(recover_file->DIR_FileSize % one_cluster == 0)//正好是整数倍的cluster大小
					{
						num_clusters = recover_file->DIR_FileSize / one_cluster;
					}
					else //不是整数倍的cluster大小
					{
						num_clusters = recover_file->DIR_FileSize / one_cluster + 1;
					}
					for (int i = 0; i < num_clusters-1; i++)
					{
						*pp = starting_cluster +1; // contiguously
						pp = pp + 1; //为什么不是pp = pp +4，不是加4bytes 吗
						starting_cluster++; 
					}
					*pp = 0x0ffffff8; //设为EOF
				}
				else
				{
					*pp = 0x0ffffff8;//设为EOF
				}
			}
			printf("%s: successfully recovered\n",raw_file);
		}
		else if(recover_num > 1)//有多个符合的文件
		{
			printf("%s: multiple candidates found\n",raw_file);
		}
		
	}

	if(rvalue != NULL && svalue != NULL) // -r filename -s sha1
	{
		char raw_file[500];
		strcpy(raw_file,rvalue);
		char raw_sha1[50];
		strcpy(raw_sha1,svalue);

		int recover_flag = 0;
		char empty_sha1[50] = {"da39a3ee5e6b4b0d3255bfef95601890afd80709"};
		int next_cluster = bp->BPB_RootClus; //第一个cluster的初始位置
		int	first_offset = bp->BPB_RsvdSecCnt * bp->BPB_BytsPerSec + bp->BPB_NumFATs * bp->BPB_FATSz32 * bp->BPB_BytsPerSec ;
		int max_entries = bp->BPB_SecPerClus * bp->BPB_BytsPerSec / 32;

		while (next_cluster < 0x0ffffff8)
		{
			int offset = first_offset + (next_cluster -2) *bp->BPB_BytsPerSec*bp->BPB_SecPerClus;
			unsigned int * pp = (unsigned int *)(addr + reser_bytes + 4 * next_cluster);
			next_cluster = * pp;

			for (int i = 0; i < max_entries; i++)
			{
				DirEntry * dp = (DirEntry *)(addr + offset + i*32);
				if(dp->DIR_Name[0] == 0) //没有文件了
					break;
				
				//get filename -- HELLO.TXT
				char filename[20] = {0};
				int name_length = 0;
				//parse name
				strcpy(filename,(char *)dp->DIR_Name);
				for (int i = 0; i < 8; i++)
				{
					if(dp->DIR_Name[i] == ' ') //foo i=3
					{
						name_length = i; // name_length = 3
						break;
					}
				}
				if(name_length == 0)
				{
					name_length = 8;
				}
				//判断是否加.
				for (int i = 8; i < 11; i++)
				{
					if(dp->DIR_Name[i] != ' ')//扩展名不为空 -- 加.
					{
						filename[name_length] = '.';
						name_length++;
						i = 100;
					}
				}
				for (int i = 8; i < 11; i++)
				{
					if(dp->DIR_Name[i] != ' ')//扩展名不为空 -- 复制
					{
						filename[name_length] = dp->DIR_Name[i];
						name_length++;
					}
				}
				filename[name_length] = '\0';	
			
				if(dp->DIR_Name[0] == 0xe5) //被删除的文件
				{
					if(!strcmp(&raw_file[1],&filename[1])) //名字相同
					{
						// printf("same name\n");
						//比较sha1
						unsigned char recover_sha1[SHA_DIGEST_LENGTH];
						// unsigned char sha1_twice[SHA_DIGEST_LENGTH * 2];
						unsigned char sha1_twice[SHA_DIGEST_LENGTH * 2];
						//访问file content
						unsigned char recover_content[dp->DIR_FileSize];
						unsigned int starting_cluster = (dp->DIR_FstClusHI << 16) + dp->DIR_FstClusLO;
						unsigned char * pp = (unsigned char *)(addr + reser_bytes + bp->BPB_NumFATs * bp->BPB_FATSz32 * bp->BPB_BytsPerSec + (starting_cluster - 2) * bp->BPB_SecPerClus * bp->BPB_BytsPerSec);
						// printf("dp->DIR_FileSize = %u\n",dp->DIR_FileSize);
						if(dp->DIR_FileSize > bp->BPB_SecPerClus * bp->BPB_BytsPerSec)// 文件大小大于一个cluster
						{
							// printf("more than one cluster\n");
							int num_clusters = 0;
							if(dp->DIR_FileSize % (bp->BPB_SecPerClus * bp->BPB_BytsPerSec) == 0)//正好是整数倍的cluster大小
							{
								num_clusters = dp->DIR_FileSize / (bp->BPB_SecPerClus * bp->BPB_BytsPerSec);
							}
							else //不是整数倍的cluster大小
							{
								num_clusters = dp->DIR_FileSize / (bp->BPB_SecPerClus * bp->BPB_BytsPerSec) + 1;
							}
							// printf("more than one cluster,num_cluster = %d\n",num_clusters);
							for (int i = 0; i < num_clusters; i++)
							{
								if(i == num_clusters - 1)//最后一个cluster
								{
									memcpy((void *)(recover_content + i * bp->BPB_SecPerClus * bp->BPB_BytsPerSec), (void *)pp ,dp->DIR_FileSize - i * bp->BPB_SecPerClus * bp->BPB_BytsPerSec);
									break;
								}
								else
								{
									// printf("i = %d, before memcpy\n",i);
									// printf("one cluster size = %d\n",bp->BPB_SecPerClus * bp->BPB_BytsPerSec);
									memcpy((void *)(recover_content + i * bp->BPB_SecPerClus * bp->BPB_BytsPerSec), (void *)pp ,bp->BPB_SecPerClus * bp->BPB_BytsPerSec);
									// printf("i = %d, after memcpy\n",i);
								}
								
								//将pp改为下一个cluster的地址
								//先获取starting_cluster
								starting_cluster = starting_cluster +1;
								pp = (unsigned char *)(addr + reser_bytes + bp->BPB_NumFATs * bp->BPB_FATSz32 * bp->BPB_BytsPerSec + (starting_cluster - 2) * bp->BPB_SecPerClus * bp->BPB_BytsPerSec);
							}
							SHA1(recover_content, dp->DIR_FileSize, recover_sha1);
							for (int i = 0; i < SHA_DIGEST_LENGTH; i++)
                            {
                                sprintf((char *)(sha1_twice + i * 2 ), "%02x", recover_sha1[i]);
							}
							// printf("sha1_twice = %s\n",sha1_twice);
						}
						else if(dp->DIR_FileSize == 0)//空文件
						{
							strcpy((char *)sha1_twice, (char *)empty_sha1);
						}
						else // 小于等于一个cluster
						{
							unsigned int starting_cluster = (dp->DIR_FstClusHI << 16) + dp->DIR_FstClusLO;
							unsigned char * pp = (unsigned char *)(addr + reser_bytes + bp->BPB_NumFATs * bp->BPB_FATSz32 * bp->BPB_BytsPerSec + (starting_cluster - 2) * bp->BPB_SecPerClus * bp->BPB_BytsPerSec);

							SHA1(pp,dp->DIR_FileSize,recover_sha1);
							
                            for (int i = 0; i < SHA_DIGEST_LENGTH; i++)
                            {
                                sprintf((char *)(sha1_twice + i * 2 ), "%02x", recover_sha1[i]);
							}
							// printf("sha1_twice = %s\n",sha1_twice);
							// printf("svalue = %s\n",svalue);					
						}
						if(!strcmp((char *)sha1_twice, (char *)svalue)) // ==
						{
							// printf("same sha1 \n");
							//恢复文件
							dp->DIR_Name[0] = raw_file[0];
							//恢复fat
							for (int i = 0; i < bp->BPB_NumFATs; i++)
							{
								unsigned int starting_cluster = (dp->DIR_FstClusHI << 16) + dp->DIR_FstClusLO;
								unsigned int * pp = (unsigned int *)(addr + reser_bytes + 4 * starting_cluster + i * bp->BPB_FATSz32 * bp->BPB_BytsPerSec);
								unsigned int one_cluster = bp->BPB_BytsPerSec * bp->BPB_SecPerClus;
								if(dp->DIR_FileSize > one_cluster) //大于一个cluster
								{
									int num_clusters = 0;
									if(dp->DIR_FileSize % one_cluster == 0)//正好是整数倍的cluster大小
									{
										num_clusters = dp->DIR_FileSize / one_cluster;
									}
									else //不是整数倍的cluster大小
									{
										num_clusters = dp->DIR_FileSize / one_cluster + 1;
									}
									for (int i = 0; i < num_clusters-1; i++)
									{
										*pp = starting_cluster +1; // contiguously
										pp = pp + 1; //为什么不是pp = pp +4，不是加4bytes 吗
										starting_cluster++; 
									}
									*pp = 0x0ffffff8; //设为EOF
								}
								else
								{
									*pp = 0x0ffffff8;//设为EOF
								}
							}
							printf("%s: successfully recovered with SHA-1\n",raw_file);
							recover_flag = 1;
							break;
						}
					}
				}
			}
			if(recover_flag == 1)
				break;
		}
		if(recover_flag == 0) //没找到
		{
			printf("%s: file not found\n",raw_file);
		}
		
	}

	if(Rvalue != NULL) // -R filename -s sha1
	{
		char raw_file[500];
		strcpy(raw_file,Rvalue);
		char raw_sha1[50];
		strcpy(raw_sha1,svalue);

		int recover_flag = 0;
		char empty_sha1[50] = {"da39a3ee5e6b4b0d3255bfef95601890afd80709"};
		int next_cluster = bp->BPB_RootClus; //第一个cluster的初始位置
		int	first_offset = bp->BPB_RsvdSecCnt * bp->BPB_BytsPerSec + bp->BPB_NumFATs * bp->BPB_FATSz32 * bp->BPB_BytsPerSec ;
		int max_entries = bp->BPB_SecPerClus * bp->BPB_BytsPerSec / 32;

		while (next_cluster < 0x0ffffff8)
		{
			int offset = first_offset + (next_cluster -2) *bp->BPB_BytsPerSec*bp->BPB_SecPerClus;
			unsigned int * pp = (unsigned int *)(addr + reser_bytes + 4 * next_cluster);
			next_cluster = * pp;

			for (int i = 0; i < max_entries; i++)
			{
				DirEntry * dp = (DirEntry *)(addr + offset + i*32);
				if(dp->DIR_Name[0] == 0) //没有文件了
					break;
				
				//get filename -- HELLO.TXT
				char filename[20] = {0};
				int name_length = 0;
				//parse name
				strcpy(filename,(char *)dp->DIR_Name);
				for (int i = 0; i < 8; i++)
				{
					if(dp->DIR_Name[i] == ' ') //foo i=3
					{
						name_length = i; // name_length = 3
						break;
					}
				}
				if(name_length == 0)
				{
					name_length = 8;
				}
				//判断是否加.
				for (int i = 8; i < 11; i++)
				{
					if(dp->DIR_Name[i] != ' ')//扩展名不为空 -- 加.
					{
						filename[name_length] = '.';
						name_length++;
						i = 100;
					}
				}
				for (int i = 8; i < 11; i++)
				{
					if(dp->DIR_Name[i] != ' ')//扩展名不为空 -- 复制
					{
						filename[name_length] = dp->DIR_Name[i];
						name_length++;
					}
				}
				filename[name_length] = '\0';	
			
				if(dp->DIR_Name[0] == 0xe5) //被删除的文件
				{
					if(!strcmp(&raw_file[1],&filename[1])) //名字相同
					{
						//比较sha1
						unsigned char recover_sha1[SHA_DIGEST_LENGTH];
						unsigned char sha1_twice[SHA_DIGEST_LENGTH * 2];
						//访问file content
						unsigned char recover_content[dp->DIR_FileSize];
						unsigned int starting_cluster = (dp->DIR_FstClusHI << 16) + dp->DIR_FstClusLO;
						unsigned char * pp = (unsigned char *)(addr + reser_bytes + bp->BPB_NumFATs * bp->BPB_FATSz32 * bp->BPB_BytsPerSec + (starting_cluster - 2) * bp->BPB_SecPerClus * bp->BPB_BytsPerSec);
						if(dp->DIR_FileSize > bp->BPB_SecPerClus * bp->BPB_BytsPerSec)// 文件大小大于一个cluster
						{
							int num_clusters = 0;
							if(dp->DIR_FileSize % (bp->BPB_SecPerClus * bp->BPB_BytsPerSec) == 0)//正好是整数倍的cluster大小
							{
								num_clusters = dp->DIR_FileSize / (bp->BPB_SecPerClus * bp->BPB_BytsPerSec);
							}
							else //不是整数倍的cluster大小
							{
								num_clusters = dp->DIR_FileSize / (bp->BPB_SecPerClus * bp->BPB_BytsPerSec) + 1;
							}
							for (int i = 0; i < num_clusters; i++)
							{
								if(i == num_clusters - 1)//最后一个cluster
								{
									memcpy((void *)(recover_content + i * bp->BPB_SecPerClus * bp->BPB_BytsPerSec), (void *)pp ,dp->DIR_FileSize - i * bp->BPB_SecPerClus * bp->BPB_BytsPerSec);
									break;
								}
								else
								{
									memcpy((void *)(recover_content + i * bp->BPB_SecPerClus * bp->BPB_BytsPerSec), (void *)pp ,bp->BPB_SecPerClus * bp->BPB_BytsPerSec);
								}
								
								//将pp改为下一个cluster的地址
								//先获取starting_cluster
								starting_cluster = starting_cluster +1;
								pp = (unsigned char *)(addr + reser_bytes + bp->BPB_NumFATs * bp->BPB_FATSz32 * bp->BPB_BytsPerSec + (starting_cluster - 2) * bp->BPB_SecPerClus * bp->BPB_BytsPerSec);
							}
							SHA1(recover_content, dp->DIR_FileSize, recover_sha1);
							for (int i = 0; i < SHA_DIGEST_LENGTH; i++)
                            {
                                sprintf((char *)(sha1_twice + i * 2 ), "%02x", recover_sha1[i]);
							}
						}
						else if(dp->DIR_FileSize == 0)//空文件
						{
							strcpy((char *)sha1_twice, (char *)empty_sha1);
						}
						else // 小于等于一个cluster
						{
							unsigned int starting_cluster = (dp->DIR_FstClusHI << 16) + dp->DIR_FstClusLO;
							unsigned char * pp = (unsigned char *)(addr + reser_bytes + bp->BPB_NumFATs * bp->BPB_FATSz32 * bp->BPB_BytsPerSec + (starting_cluster - 2) * bp->BPB_SecPerClus * bp->BPB_BytsPerSec);

							SHA1(pp,dp->DIR_FileSize,recover_sha1);
							
                            for (int i = 0; i < SHA_DIGEST_LENGTH; i++)
                            {
                                sprintf((char *)(sha1_twice + i * 2 ), "%02x", recover_sha1[i]);
							}
						}
						if(!strcmp((char *)sha1_twice, (char *)svalue)) // ==
						{
							//恢复文件
							dp->DIR_Name[0] = raw_file[0];
							//恢复fat
							for (int i = 0; i < bp->BPB_NumFATs; i++)
							{
								unsigned int starting_cluster = (dp->DIR_FstClusHI << 16) + dp->DIR_FstClusLO;
								unsigned int * pp = (unsigned int *)(addr + reser_bytes + 4 * starting_cluster + i * bp->BPB_FATSz32 * bp->BPB_BytsPerSec);
								unsigned int one_cluster = bp->BPB_BytsPerSec * bp->BPB_SecPerClus;
								if(dp->DIR_FileSize > one_cluster) //大于一个cluster
								{
									int num_clusters = 0;
									if(dp->DIR_FileSize % one_cluster == 0)//正好是整数倍的cluster大小
									{
										num_clusters = dp->DIR_FileSize / one_cluster;
									}
									else //不是整数倍的cluster大小
									{
										num_clusters = dp->DIR_FileSize / one_cluster + 1;
									}
									for (int i = 0; i < num_clusters-1; i++)
									{
										*pp = starting_cluster +1; // contiguously
										pp = pp + 1; //为什么不是pp = pp +4，不是加4bytes 吗
										starting_cluster++; 
									}
									*pp = 0x0ffffff8; //设为EOF
								}
								else
								{
									*pp = 0x0ffffff8;//设为EOF
								}
							}
							printf("%s: successfully recovered with SHA-1\n",raw_file);
							recover_flag = 1;
							break;
						}
					}
				}
			}
			if(recover_flag == 1)
				break;
		}
		if(recover_flag == 0) //没找到
		{
			printf("%s: file not found\n",raw_file);
		}
	}

	return 0;
}

//恢复文件名
							